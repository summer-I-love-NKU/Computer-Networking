
#include <Windows.h>
#include <TOM.h>
#include <string.h>
#include <tchar.h>
#include <stdio.h>
#include <map>
#define ID_STATIC 1
#define ID_TEXT 2
#define ID_TEXTSEND 3
#define ID_CLOSE 4
#define ID_SEND 5
#define ID_LISTEN 6
#define ID_CLIENTLIST 7
#define ID_TIMER1 10
using namespace std;
#pragma comment(lib,"wsock32.lib")


